module.exports = {
  search: require('./Search'),
  sendMessage: require('./SendMessage'),
};
