### Class [Long](Long.md)

A Long class for representing a 64 bit two's-complement integer value.

---
*Generated with [doco](https://github.com/dcodeIO/doco) v0.3.0*
