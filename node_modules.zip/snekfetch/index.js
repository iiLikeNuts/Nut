const Snekfetch = require('./src/index.js');

// Sync stuff might go here

module.exports = Snekfetch;
