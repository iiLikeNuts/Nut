if your pr is about typescript go away
