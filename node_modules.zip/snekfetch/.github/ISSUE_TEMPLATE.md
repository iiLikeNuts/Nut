if your issue is about typescript go away
