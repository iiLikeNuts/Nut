const Prism = require('./Prism');
const MediaTranscoder = require('./transcoders/MediaTranscoder');

Prism.MediaTranscoder = MediaTranscoder;

module.exports = Prism;
